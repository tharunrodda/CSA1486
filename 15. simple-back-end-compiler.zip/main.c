#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

// Stack structure for holding intermediate values
typedef struct Stack {
    int top;
    unsigned capacity;
    char** array;
} Stack;

// Function to create a stack
Stack* createStack(unsigned capacity) {
    Stack* stack = (Stack*) malloc(sizeof(Stack));
    stack->capacity = capacity;
    stack->top = -1;
    stack->array = (char**) malloc(stack->capacity * sizeof(char*));
    return stack;
}

// Stack operations
int isFull(Stack* stack) {
    return stack->top == stack->capacity - 1;
}

int isEmpty(Stack* stack) {
    return stack->top == -1;
}

void push(Stack* stack, char* item) {
    if (isFull(stack)) {
        return;
    }
    stack->array[++stack->top] = item;
}

char* pop(Stack* stack) {
    if (isEmpty(stack)) {
        return NULL;
    }
    return stack->array[stack->top--];
}

// Function to generate assembly code for a given postfix expression
void generateAssemblyCode(char* postfix) {
    Stack* stack = createStack(strlen(postfix));
    int regCounter = 0;
    char reg[10];

    for (int i = 0; i < strlen(postfix); i++) {
        char ch = postfix[i];

        if (isdigit(ch)) {
            char* num = (char*) malloc(2 * sizeof(char));
            num[0] = ch;
            num[1] = '\0';
            push(stack, num);
        } else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
            char* operand2 = pop(stack);
            char* operand1 = pop(stack);

            sprintf(reg, "R%d", regCounter++);
            printf("LOAD %s\n", operand1);
            printf("%s %s\n", (ch == '+' ? "ADD" : ch == '-' ? "SUB" : ch == '*' ? "MUL" : "DIV"), operand2);
            printf("STORE %s\n", reg);

            char* result = (char*) malloc(10 * sizeof(char));
            strcpy(result, reg);
            push(stack, result);

            free(operand1);
            free(operand2);
        }
    }

    free(stack->array);
    free(stack);
}

int main() {
    // Sample postfix expression (assuming front end of compiler provided this)
    char postfix[] = "23+56-*";

    printf("Generating assembly code for postfix expression: %s\n", postfix);
    generateAssemblyCode(postfix);

    return 0;
}
