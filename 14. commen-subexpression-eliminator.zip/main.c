#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_EXPRESSIONS 100
#define MAX_EXPRESSION_LENGTH 50

typedef struct {
    char expression[MAX_EXPRESSION_LENGTH];
    char result[MAX_EXPRESSION_LENGTH];
} Expression;

Expression expressions[MAX_EXPRESSIONS];
int expressionCount = 0;

void addExpression(const char *expression, const char *result) {
    strcpy(expressions[expressionCount].expression, expression);
    strcpy(expressions[expressionCount].result, result);
    expressionCount++;
}

char* findCommonSubexpression(const char *expression) {
    for (int i = 0; i < expressionCount; i++) {
        if (strcmp(expressions[i].expression, expression) == 0) {
            return expressions[i].result;
        }
    }
    return NULL;
}

void optimizeExpressions() {
    for (int i = 0; i < expressionCount; i++) {
        char *commonResult = findCommonSubexpression(expressions[i].expression);
        if (commonResult) {
            printf("Common subexpression found: %s, using result: %s\n",
                   expressions[i].expression, commonResult);
        } else {
            printf("Evaluating: %s, result: %s\n",
                   expressions[i].expression, expressions[i].result);
            addExpression(expressions[i].expression, expressions[i].result);
        }
    }
}

int main() {
    // Sample expressions and results
    addExpression("a + b", "t1");
    addExpression("c + d", "t2");
    addExpression("a + b", "t1");  // Common subexpression
    addExpression("e + f", "t3");
    addExpression("c + d", "t2");  // Common subexpression

    printf("Optimizing expressions...\n");
    optimizeExpressions();

    return 0;
}
