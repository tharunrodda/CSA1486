#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_EXPRESSION_LENGTH 100
#define MAX_TAC_LENGTH 100

typedef struct {
    char result[10];
    char arg1[10];
    char op[2];
    char arg2[10];
} TAC;

TAC tac[MAX_TAC_LENGTH];
int tacIndex = 0;
int tempVarCount = 0;

char* newTempVar() {
    char* tempVar = (char*)malloc(10 * sizeof(char));
    sprintf(tempVar, "t%d", tempVarCount++);
    return tempVar;
}

void generateTAC(char* result, char* arg1, char* op, char* arg2) {
    strcpy(tac[tacIndex].result, result);
    strcpy(tac[tacIndex].arg1, arg1);
    strcpy(tac[tacIndex].op, op);
    strcpy(tac[tacIndex].arg2, arg2);
    tacIndex++;
}

char* parseExpression(char* expr) {
    char* tempVar1 = newTempVar();
    char* tempVar2 = newTempVar();
    char op[2] = {0};
    char left[50] = {0};
    char right[50] = {0};
    
    int i = 0, j = 0;
    int opFound = 0;

    // Split the expression into left and right parts around the operator
    while (expr[i] != '\0') {
        if (expr[i] == '+' || expr[i] == '-' || expr[i] == '*' || expr[i] == '/') {
            opFound = 1;
            op[0] = expr[i];
            i++;
            continue;
        }
        if (!opFound) {
            left[j++] = expr[i];
        } else {
            right[j++] = expr[i];
        }
        i++;
    }
    left[j] = '\0';
    right[j] = '\0';

    // Recursively parse left and right expressions
    if (strlen(left) > 1 && (strchr(left, '+') || strchr(left, '-') || strchr(left, '*') || strchr(left, '/'))) {
        strcpy(tempVar1, parseExpression(left));
    } else {
        strcpy(tempVar1, left);
    }

    if (strlen(right) > 1 && (strchr(right, '+') || strchr(right, '-') || strchr(right, '*') || strchr(right, '/'))) {
        strcpy(tempVar2, parseExpression(right));
    } else {
        strcpy(tempVar2, right);
    }

    char* tempResult = newTempVar();
    generateTAC(tempResult, tempVar1, op, tempVar2);
    return tempResult;
}

void printTAC() {
    printf("\nThree-Address Code:\n");
    for (int i = 0; i < tacIndex; i++) {
        printf("%s = %s %s %s\n", tac[i].result, tac[i].arg1, tac[i].op, tac[i].arg2);
    }
}

int main() {
    char expression[MAX_EXPRESSION_LENGTH];
    printf("Enter an arithmetic expression: ");
    scanf("%s", expression);

    parseExpression(expression);
    printTAC();

    return 0;
}
