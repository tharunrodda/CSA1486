#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

const char *input;
int pos = 0;

void E();
void E_prime();
void T();
void T_prime();
void F();

void error() {
    printf("Error parsing input at position %d: unexpected character '%c'\n", pos, input[pos]);
    exit(1);
}

void match(char expected) {
    if (input[pos] == expected) {
        pos++;
    } else {
        error();
    }
}

void E() {
    T();
    E_prime();
}

void E_prime() {
    while (input[pos] == '+') {
        match('+');
        T();
    }
}

void T() {
    F();
    T_prime();
}

void T_prime() {
    while (input[pos] == '*') {
        match('*');
        F();
    }
}

void F() {
    if (input[pos] == '(') {
        match('(');
        E();
        match(')');
    } else if (isalpha(input[pos])) {
        match(input[pos]);
    } else {
        error();
    }
}

int main() {
    char inputStr[100];
    printf("Enter an arithmetic expression: ");
    scanf("%s", inputStr);
    input = inputStr;

    E();
    if (input[pos] == '\0') {
        printf("Parsing successful\n");
    } else {
        error();
    }

    return 0;
}
